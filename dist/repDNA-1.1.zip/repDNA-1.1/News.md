# Version 1.1 (2014-10-08)

- Fix the denominator(l - k - lambda + 1) bug in calculating theta in psenacutil module and change the test file and documents.
- Optimize the code and add some comments.
- Add the News file.

# Version 1.0 (2014-09-17)

- repDNA package release.